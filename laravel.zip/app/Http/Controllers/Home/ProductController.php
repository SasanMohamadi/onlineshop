<?php

namespace App\Http\Controllers\home;

use App\Http\Controllers\Controller;
use App\Models\product;
use Illuminate\Http\Request;

class ProductController extends Controller
{

    public function show(product $product){

        return view('home.products.show', compact('product'));

    }
}
