<?php

namespace App\Http\Controllers\Home;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class categoryController extends Controller
{
    public function show(Request $request, Category $category){


       $products = $category->products()->filter()->search()->paginate(9);

        $attributes = $category->attributes()->where('is_filter', 1 )->with('values')->get();
        $variation = $category->attributes()->where('is_variation', 1 )->with('variationValues')->first();


        return view('home.categories.show', compact('attributes', 'variation', 'category', 'products'));
    }
}
