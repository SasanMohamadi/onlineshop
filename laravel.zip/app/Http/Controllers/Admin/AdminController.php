<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index(){

        $month =12;

        $successTransactions = Transaction::getData($month, 1);
        $successTransactionschart = $this->chart($successTransactions,  $month);

        $unsuccessTransactions = Transaction::getData($month, 0);
        $unsuccessTransactionschart = $this->chart($unsuccessTransactions,  $month);

        return view('admin.dashboard', [

            'successTransactions' => array_values($successTransactionschart),
            'labels' => array_keys($successTransactionschart),
            'unsuccessTransactions' => array_values($unsuccessTransactionschart),
            'transactioncount' => [$successTransactions->count(),$unsuccessTransactions->count()]
        ]);
    }


    public function chart($Transactions,  $month){
        $monthName = $Transactions->map(function($item){
            return verta($item->created_at)->format('%B %y');
        });

        $amount = $Transactions->map(function($item){
            return $item->amount;
        });
        // $result = [];
        foreach($monthName as $k => $v){
            if(!isset( $result[$v])){
                $result[$v] = 0;
            }
            $result[$v] += $amount[$k];

        }

        if(count($result) < $month){
            for($i= 0; $i< $month ; $i++){
                $monthName = verta()->subMonth($i)->format('%B %y');
                $shmsiMonths[$monthName] = 0 ;
            }
           return array_reverse(array_merge($shmsiMonths,  $result));
        }
        return $result;
    }
}
