<?php

namespace App\Models;

// use Attribute;
use App\Models\product;
use App\Models\attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProductAttribute extends Model
{
    use HasFactory;
    protected $table = "product_attributes";
    protected $guarded = [];


    public function attribute()
    {
        return $this->belongsTo(attribute::class);
    }
    public function product()
    {
        return $this->belongsTo(product::class);
    }

}
