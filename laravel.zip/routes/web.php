<?php

use App\Http\Controllers\admin\AdminController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\TagController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\home\CartController;
use App\Http\Controllers\Home\HomeController;
use App\Http\Controllers\admin\RoleController;
use App\Http\Controllers\admin\UserController;
use App\Http\Controllers\Admin\BrandController;
use App\Http\Controllers\admin\OrderController;
use App\Http\Controllers\admin\BannerController;
use App\Http\Controllers\admin\CouponController;
use App\Http\Controllers\home\AddressController;
use App\Http\Controllers\home\CompareController;
use App\Http\Controllers\home\PaymentController;
use App\Http\Controllers\home\SitemapController;
use App\Http\Controllers\admin\CommentController;
use App\Http\Controllers\admin\ProductController;
use App\Http\Controllers\home\WishlistController;
use App\Http\Controllers\admin\CategoryController;
use App\Http\Controllers\admin\AttributeController;
use App\Http\Controllers\admin\PermissionController;
use App\Http\Controllers\home\UserProfileController;
use App\Http\Controllers\admin\TransactionController;
use App\Http\Controllers\admin\ProductImageController;
use App\Http\Controllers\home\CommentController as HomeCommentController;
use App\Http\Controllers\home\ProductController as homeProductController;
use App\Http\Controllers\Home\categoryController as homeCategoryController;


// use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/admin-panel/dashboard', [AdminController::class, 'index'])->name('dashboard');


Route::prefix('admin-panel/managment')->name('admin.')->middleware(['role:admin'])->group(function(){

    route::resource('brands', BrandController::class);
    route::resource('attributes', AttributeController::class);
    route::resource('categories', CategoryController::class);
    route::resource('tags', TagController::class);
    route::resource('products', ProductController::class);
    route::resource('banners', BannerController::class);
    route::resource('comments', CommentController::class);
    route::resource('coupons', CouponController::class);
    route::resource('orders', OrderController::class);
    route::resource('transactions', TransactionController::class);
    route::resource('users', UserController::class);
    route::resource('permissions', PermissionController::class);
    route::resource('roles', RoleController::class);

    Route::get('/comments/{comment}/change-approve', [CommentController::class, 'changeApprove'])->name('comments.change-approve');
    //get category attributes
    Route::get('/category-attributes/{category}', [CategoryController::class, 'getCategoryAttributes']);

    // edit image product
    Route::get('/products/{product}/images-edit', [ProductImageController::class, 'edit'])->name('products.images.edit');
    Route::delete('/products/{product}/images-destroy', [ProductImageController::class, 'destroy'])->name('products.images.destroy');
    Route::put('/products/{product}/images-set-primary', [ProductImageController::class, 'setPrimary'])->name('products.images.set_primary');
    Route::post('/products/{product}/images-add', [ProductImageController::class, 'add'])->name('products.images.add');

    // edit category product
    Route::get('/products/{product}/category-edit', [ProductController::class, 'editCategory'])->name('products.category.edit');
    Route::put('/products/{product}/category-update', [ProductController::class, 'updateCategory'])->name('products.category.update');

});


Route::get('/', [HomeController::class, 'index'])->name('home.index');

Route::get('/categories/{category:slug}', [homeCategoryController::class, 'show'])->name('home.categories.show');
Route::get('/products/{product:slug}', [homeProductController::class, 'show'])->name('home.products.show');
Route::post('/comments/{product}', [HomeCommentController::class, 'store'])->name('home.comments.store');

Route::get('/add-to-wishlist/{product}', [WishlistController::class, 'add'])->name('home.wishlist.add');
Route::get('/remove-from-wishlist/{product}', [WishlistController::class, 'remove'])->name('home.wishlist.remove');

Route::get('/compare', [CompareController::class, 'index'])->name('home.compare.index');
Route::get('/add-to-compare/{product}', [CompareController::class, 'add'])->name('home.compare.add');
Route::get('/remove-from-compare/{product}', [CompareController::class, 'remove'])->name('home.compare.remove');



Route::get('/clear-cart', [CartController::class, 'clear'])->name('home.cart.clear');
Route::put('/cart', [CartController::class, 'update'])->name('home.cart.update');
Route::get('/cart', [CartController::class, 'index'])->name('home.cart.index');
Route::post('/add-to-cart', [CartController::class, 'add'])->name('home.cart.add');
Route::get('/remove-from-cart/{rowId}', [CartController::class, 'remove'])->name('home.cart.remove');
Route::post('/check-coupon', [CartController::class, 'checkCoupon'])->name('home.coupons.check');
Route::get('/checkout', [CartController::class, 'checkout'])->name('home.orders.checkout');

Route::post('/payment', [PaymentController::class, 'payment'])->name('home.payment');
Route::get('/payment-verify/{gatewayName}', [PaymentController::class, 'paymentVerify'])->name('home.payment_verify');


route::get('/login/{provider}', [AuthController::class, 'redirectToProvider'])->name('provider.login');
route::get('/login/{provider}/callback', [AuthController::class, 'handleProviderCallback']);

Route::prefix('profile')->name('home.')->group(function(){
    Route::get('/', [UserProfileController::class, 'index'])->name('users_profile.index');
    Route::get('/comments', [HomeCommentController::class, 'usersProfileIndex'])->name('comments.users_profile.index');
    Route::get('/wishlist', [WishlistController::class, 'usersProfileIndex'])->name('wishlists.users_profile.index');

    Route::get('/addresses', [AddressController::class, 'index'])->name('addresses.index');
    Route::post('/addresses', [AddressController::class, 'store'])->name('addresses.store');
    Route::put('/addresses/{address}', [AddressController::class, 'update'])->name('addresses.update');

    Route::get('/orders', [CartController::class, 'usersProfileIndex'])->name('orders.users_profile.index');
});

Route::get('/get-province-cities-list', [AddressController::class, 'getProvinceCitiesList']);


Route::get('/about-us', [HomeController::class, 'aboutUs'])->name('home.about-us');
Route::get('/contact-us', [HomeController::class, 'contactUs'])->name('home.contact-us');
Route::post('/contact-us-form', [HomeController::class, 'contactUsForm'])->name('home.contact-us.form');

Route::get('/sitemap', [SitemapController::class, 'index'])->name('home.sitemap.index');
Route::get('/sitemap-tags', [SitemapController::class, 'sitemapTags'])->name('home.sitemap.tags');
Route::get('/sitemap-products', [SitemapController::class, 'sitemapProducts'])->name('home.sitemap.products');

Route::get('/test', function () {
    // dd(\Cart::getContent());
});
